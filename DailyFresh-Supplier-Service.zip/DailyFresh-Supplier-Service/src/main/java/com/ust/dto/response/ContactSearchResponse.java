package com.ust.dto.response;

import com.ust.model.Contact;


public class ContactSearchResponse {
	int statusCode;
	String description;
	Contact contact;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "ContactSearchResponse [statusCode=" + statusCode + ", description=" + description + ", contact="
				+ contact + "]";
	}
	
	
	
}
