package com.ust.dto.response;

import java.util.List;

import com.ust.model.Contact;


public class ContactShowAllResponse {
	int statusCode;
	String description;
	List<Contact> contacts;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}
	@Override
	public String toString() {
		return "ContactShowAllResponse [statusCode=" + statusCode + ", description=" + description + ", contacts="
				+ contacts + "]";
	}
	
	
	
}
