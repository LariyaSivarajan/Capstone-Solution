package com.ust.dto.request;

import com.ust.model.Contact;

public class ContactDeleteRequest {
  Contact contact;

public Contact getContact() {
	return contact;
}

public void setContact(Contact contact) {
	this.contact = contact;
}
  
  
  
}
