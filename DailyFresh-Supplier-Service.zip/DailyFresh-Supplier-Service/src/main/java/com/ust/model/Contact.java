package com.ust.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="contacts")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private int contactId;
	
	@Column
	//@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	//@Size(min=3,max=50, message="Length of name should be between 3 to 50")
	String contactPersonName;
	
	@Column
	//@Pattern(regexp="^[0-9]{10}$",message="Length of phone should be 10")
	String contactPhoneNumber;
	
	@Column
	//@Email(message="Please enter valid email")
	private String contactEmail;
	@JoinColumn(name="contactId",referencedColumnName = "supplierId")
	@OneToOne(cascade =CascadeType.ALL)
	Supplier supplier;

	
	
}
