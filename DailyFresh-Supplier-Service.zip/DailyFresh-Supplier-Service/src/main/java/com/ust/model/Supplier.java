package com.ust.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="suppliers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Supplier {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private int supplierId;
	
	@Column
	@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of name should be between 3 to 20")
	String supplierName;
	
	@Column
	@NotEmpty(message="City is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of city should be between 3 to 20")
	private String supplierCity;

	
	
	@OneToOne(cascade =CascadeType.ALL)
	private Contact contact;
}
