package com.ust.exception;

public class SupplierNotFoundException extends Exception{

	public SupplierNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SupplierNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SupplierNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SupplierNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SupplierNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
 /*public VisitorNotFoundException(String message){
	 
	 super(message);
 }*/
	
}
