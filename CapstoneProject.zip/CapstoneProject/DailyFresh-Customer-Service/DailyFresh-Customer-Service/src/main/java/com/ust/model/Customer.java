package com.ust.model;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Table(name="customers")

public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int customerId;
	
	@Column
	@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of name should be between 3 to 20")
	String customerName;
	
	@Embedded
	private Address address;
	
	@Column
	@Email(message="Please enter valid email")
	private String customerEmail;
	
	@Column
	@Pattern(regexp="^[0-9]{10}$",message="Length of phone should be 10")
	String customerPhoneNumber;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public Customer() {
		super();
	}

	public Customer(int customerId,
			@NotEmpty(message = "Name is mandatory.....Cannot be left blank") @Size(min = 3, max = 20, message = "Length of name should be between 3 to 20") String customerName,
			Address address, @Email(message = "Please enter valid email") String customerEmail,
			@Pattern(regexp = "^[0-9]{10}$", message = "Length of phone should be 10") String customerPhoneNumber) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", address=" + address
				+ ", customerEmail=" + customerEmail + ", customerPhoneNumber=" + customerPhoneNumber + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(customerId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return customerId == other.customerId;
	}

	
	
}
