package com.ust.dto.request;

import com.ust.model.Customer;


public class CustomerUpdateRequest {
	Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
