package com.ust.db;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.model.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{
  List<Customer> findByAddress_City(String city);
  List<Customer> findByAddress_Location(String location);
}
