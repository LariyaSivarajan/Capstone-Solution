package com.ust.dto.response;

import com.ust.model.Bill;

public class BillModifyResponse {
	int statusCode;
	String description;
	Bill bill;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	@Override
	public String toString() {
		return "BillModifyResponse [statusCode=" + statusCode + ", description=" + description + ", bill=" + bill + "]";
	}
	
	
	
}
