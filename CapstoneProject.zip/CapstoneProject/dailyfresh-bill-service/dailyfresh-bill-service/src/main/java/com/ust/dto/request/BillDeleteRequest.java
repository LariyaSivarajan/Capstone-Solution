package com.ust.dto.request;

import com.ust.model.Bill;


public class BillDeleteRequest {
	 Bill bill;

	 public Bill getBill() {
	 	return bill;
	 }

	 public void setBill(Bill bill) {
	 	this.bill = bill;
	 }
  
  
  
}
