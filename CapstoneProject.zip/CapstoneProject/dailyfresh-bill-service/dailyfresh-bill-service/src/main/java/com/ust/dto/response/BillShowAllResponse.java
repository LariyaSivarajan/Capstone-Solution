package com.ust.dto.response;

import java.util.List;

import com.ust.model.Bill;


public class BillShowAllResponse {
	int statusCode;
	String description;
	List<Bill> bills;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Bill> getBills() {
		return bills;
	}
	public void setBills(List<Bill> bills) {
		this.bills = bills;
	}
	@Override
	public String toString() {
		return "BillShowAllResponse [statusCode=" + statusCode + ", description=" + description + ", bills=" + bills
				+ "]";
	}
	
	
	
	
}
