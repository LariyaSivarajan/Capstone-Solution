package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ust.db.CustomerRepository;

import com.ust.model.Customer;


@Service
public class CustomerService  {
	
@Autowired
CustomerRepository repo;
	public Customer addNewCustomer(Customer customer) {
		return repo.save(customer);
	}
	
	public Customer updateContact(Customer customer) {
		return repo.save(customer);
		
	}
public Customer searchContact(Customer customer) {
	  Optional<Customer> optional=repo.findById(customer.getCustomerId());
	  
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}

public Customer searchCustomer(int id) {
	  Optional<Customer> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}
public List<Customer> getAllCustomers(){
	  return repo.findAll();
}
public boolean deleteCustomer(Customer customer) {
	  repo.delete(customer);
	  return true;
}
}