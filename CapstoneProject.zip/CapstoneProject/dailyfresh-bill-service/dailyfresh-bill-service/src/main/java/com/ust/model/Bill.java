package com.ust.model;

import java.time.LocalDateTime;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;


@Entity
@Table(name="bills")
public class Bill {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int billNumber;
	
	@Column
	 @NotNull(message = "Bill date must not be null")
    private LocalDateTime billDate;
	
	
	 @ManyToOne // ✅ This tells Hibernate it's a relationship
	    @JoinColumn(name = "customerId") // ✅ Optional but good for clarity
	    private Customer customer;
	
	@Column
	@NotEmpty(message="Item is mandatory.....Cannot be left blank")
	private String billItem;
	
	@Column
	@NotNull(message = "Bill amount is required")
	@DecimalMin(value = "0.01", message = "Bill amount must be greater than zero")
	private double billAmount;
	
	@Column
	
	private int rewardPoints;

	public int getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(int billNumber) {
		this.billNumber = billNumber;
	}

	

	public LocalDateTime getBillDate() {
		return billDate;
	}

	public void setBillDate(LocalDateTime billDate) {
		this.billDate = billDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getBillItem() {
		return billItem;
	}

	public void setBillItem(String billItem) {
		this.billItem = billItem;
	}

	public double getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}

	public double getRewardPoints() {
		return rewardPoints;
	}

	public void setRewardPoints(int rewardPoints) {
		this.rewardPoints = rewardPoints;
	}

	

	public Bill() {
		super();
	}

	

	@Override
	public String toString() {
		return "Bill [billNumber=" + billNumber + ", billDate=" + billDate + ", customer=" + customer + ", billItem="
				+ billItem + ", billAmount=" + billAmount + ", rewardPoints=" + rewardPoints + "]";
	}

	public Bill(int billNumber,
			@NotEmpty(message = "Date is mandatory.....Cannot be left blank") LocalDateTime billDate, Customer customer,
			@NotEmpty(message = "Item is mandatory.....Cannot be left blank") String billItem,
			@NotEmpty(message = "BillAmount is mandatory.....Cannot be left blank") double billAmount,
			@NotEmpty(message = "Reward is mandatory.....Cannot be left blank") int rewardPoints) {
		super();
		this.billNumber = billNumber;
		this.billDate = billDate;
		this.customer = customer;
		this.billItem = billItem;
		this.billAmount = billAmount;
		this.rewardPoints = rewardPoints;
	}

	@Override
	public int hashCode() {
		return Objects.hash(billNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		return billNumber == other.billNumber;
	}
	

}
