package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.BillAddRequest;
import com.ust.dto.request.BillDeleteRequest;
import com.ust.dto.request.BillUpdateRequest;
import com.ust.dto.response.BillAddResponse;
import com.ust.dto.response.BillDeleteResponse;
import com.ust.dto.response.BillModifyResponse;
import com.ust.dto.response.BillSearchResponse;
import com.ust.dto.response.BillShowAllResponse;
import com.ust.exception.BillNotFoundException;
import com.ust.model.Bill;
import com.ust.service.BillService;





@RestController
@RequestMapping(value = "/api")
public class BillController {
	@Autowired
	BillService service;

	@PostMapping(value = "/add")
	public ResponseEntity<BillAddResponse> f1(@RequestBody BillAddRequest request) {
		Bill bill1 = this.service.addNewBill(request.getBill());
		BillAddResponse response = new BillAddResponse();
		response.setStatusCode(200);
		response.setDescription("Bill Added Successfully");
		response.setBill(bill1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<BillModifyResponse> f2(@RequestBody BillUpdateRequest request) {
		BillModifyResponse response = new BillModifyResponse();
		Bill bill1 = this.service.searchBill(request.getBill());
		if (bill1 != null) {
			Bill bill2 = this.service.updateBill(request.getBill());

			response.setStatusCode(200);
			response.setDescription("Bill Modified Successfully");
			response.setBill(bill2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Bill Not Found for Modification");
			response.setBill(null);
			return new ResponseEntity<BillModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{billid}")
	public ResponseEntity<BillSearchResponse> f3(@PathVariable(name = "billid") int billid) throws Exception {
		BillSearchResponse response = new BillSearchResponse();
		Bill bill = this.service.searchBill(billid);
		if (bill != null) {
			response.setStatusCode(200);
			response.setDescription("Bill Fetched Successfully");
			response.setBill(bill);
			return new ResponseEntity<BillSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new BillNotFoundException("Bill Not Found");
			throw exception;
		}

		/*
		 * else { response.setStatusCode(404);
		 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
		 * return new
		 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
		 */

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<BillShowAllResponse> f4() {
		List<Bill> bills = this.service.getAllBills();
		BillShowAllResponse response = new BillShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Bills Fetched");
		response.setBills(bills);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<BillDeleteResponse> f5(@RequestBody BillDeleteRequest request) {
		BillDeleteResponse response = new BillDeleteResponse();
		Bill bill1 = this.service.searchBill(request.getBill());
		if (bill1 != null) {

			try {
				this.service.deleteBill(request.getBill());
				response.setStatusCode(200);
				response.setDescription("Bill Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("Bill Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Bill Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	/*@GetMapping(value = "/showAllBySupplierName/{name}")
	public ResponseEntity<SupplierShowAllByContactNameResponse> f6(@PathVariable(name = "name") String supplierName) {
		SupplierShowAllByContactNameResponse response = new SupplierShowAllByContactNameResponse();
		List<Supplier> suppliersBySameName = this.service.getSuppliersByName(supplierName);
		if (suppliersBySameName.isEmpty()) {
			response.setStatusCode(200);
			response.setDescription("There are no Suppliers by same name" + supplierName);
			response.setSuppliers(suppliersBySameName);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + suppliersBySameName.size() + "with same Name" + supplierName);
			response.setSuppliers(suppliersBySameName);
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping(value = "/showAllBySupplierCity", produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<SupplierShowSupplierCityResponse> f7(@RequestParam(name = "txt_city") String supplierCity) {
		SupplierShowSupplierCityResponse response = new SupplierShowSupplierCityResponse();
		List<Supplier> supplierByCity = this.service.getSuppliersByCity(supplierCity);
		if (supplierByCity!=null) {
			response.setStatusCode(200);
			response.setDescription("There are no suppliers having same phone number" + supplierCity);
			response.setSuppliers(supplierByCity);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + supplierByCity + "with same phone number" + supplierCity);
			response.setSuppliers(supplierByCity);
		}
		return ResponseEntity.ok(response);
	}*/
}