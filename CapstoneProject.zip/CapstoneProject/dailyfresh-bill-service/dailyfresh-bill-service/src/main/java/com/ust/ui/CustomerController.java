package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.CustomerAddRequest;
import com.ust.dto.request.CustomerDeleteRequest;
import com.ust.dto.request.CustomerUpdateRequest;
import com.ust.dto.response.CustomerAddResponse;
import com.ust.dto.response.CustomerDeleteResponse;
import com.ust.dto.response.CustomerModifyResponse;
import com.ust.dto.response.CustomerSearchResponse;
import com.ust.dto.response.CustomerShowAllResponse;
import com.ust.exception.CustomerNotFoundException;
import com.ust.model.Customer;


import com.ust.service.CustomerService;

@RestController
@RequestMapping(value = "/customerapi")
public class CustomerController {
	
@Autowired
CustomerService service;

@PostMapping(value = "/add")
public ResponseEntity<CustomerAddResponse> f1(@RequestBody CustomerAddRequest request) {
	Customer customer1 = this.service.addNewCustomer(request.getCustomer());
	CustomerAddResponse response = new CustomerAddResponse();
	response.setStatusCode(200);
	response.setDescription("Customer Added Successfully");
	response.setCustomer(customer1);
	return new ResponseEntity<>(response, HttpStatus.CREATED);

}

@PutMapping(value = "/modify")
public ResponseEntity<CustomerModifyResponse> f2(@RequestBody CustomerUpdateRequest request) {
	CustomerModifyResponse response = new CustomerModifyResponse();
	Customer customer1 = this.service.searchContact(request.getCustomer());
	if (customer1 != null) {
		Customer customer2 = this.service.updateContact(request.getCustomer());

		response.setStatusCode(200);
		response.setDescription("Customer Modified Successfully");
		response.setCustomer(customer2);
		return ResponseEntity.ok(response);
	} else {
		response.setStatusCode(404);
		response.setDescription("Customer Not Found for Modification");
		response.setCustomer(null);
		return new ResponseEntity<CustomerModifyResponse>(response, HttpStatus.NOT_FOUND);
	}

	// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
}

@GetMapping(value = "/find/{custid}")
public ResponseEntity<CustomerSearchResponse> f3(@PathVariable(name = "custid") int custid) throws Exception {
	CustomerSearchResponse response = new CustomerSearchResponse();
	Customer customer = this.service.searchCustomer(custid);
	if (customer != null) {
		response.setStatusCode(200);
		response.setDescription("Customer Fetched Successfully");
		response.setCustomer(customer);;
		return new ResponseEntity<CustomerSearchResponse>(response, HttpStatus.OK);
	} else {
		Exception exception = new CustomerNotFoundException("Customer Not Found");
		throw exception;
	}

	/*
	 * else { response.setStatusCode(404);
	 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
	 * return new
	 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
	 */

}

@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
public ResponseEntity<CustomerShowAllResponse> f4() {
	List<Customer> customers = this.service.getAllCustomers();
	CustomerShowAllResponse response = new CustomerShowAllResponse();
	response.setStatusCode(200);
	response.setDescription("All Customers Fetched");
	response.setCustomers(customers);
	return ResponseEntity.ok(response);
}

@DeleteMapping(value = "/delete")
public ResponseEntity<CustomerDeleteResponse> f5(@RequestBody CustomerDeleteRequest request) {
	CustomerDeleteResponse response = new CustomerDeleteResponse();
	Customer customer1 = this.service.searchContact(request.getCustomer());
	if (customer1 != null) {

		try {
			this.service.deleteCustomer(request.getCustomer());
			response.setStatusCode(200);
			response.setDescription("Customer Deleted Successfully");
			response.setDeleteStatus(true);
			return ResponseEntity.ok().body(response);

		} catch (Exception e) {
			// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
			response.setStatusCode(500);
			response.setDescription("Customer Not Deleted");
			response.setDeleteStatus(false);
			return ResponseEntity.internalServerError().body(response);
		}
	} else {
		response.setStatusCode(404);
		response.setDescription("Customer Not Found");
		response.setDeleteStatus(false);
		return new ResponseEntity(response, HttpStatus.NOT_FOUND);
	}
}
	
}
