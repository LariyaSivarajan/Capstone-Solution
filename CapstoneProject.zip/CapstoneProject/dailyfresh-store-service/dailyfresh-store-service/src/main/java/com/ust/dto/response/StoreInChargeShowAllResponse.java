package com.ust.dto.response;

import java.util.List;

import com.ust.model.StoreInCharge;



public class StoreInChargeShowAllResponse {
	int statusCode;
	String description;
	List<StoreInCharge> storeInCharges;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<StoreInCharge> getStoreInCharges() {
		return storeInCharges;
	}
	public void setStoreInCharges(List<StoreInCharge> storeInCharges) {
		this.storeInCharges = storeInCharges;
	}
	@Override
	public String toString() {
		return "StoreInChargeShowAllResponse [statusCode=" + statusCode + ", description=" + description
				+ ", storeInCharges=" + storeInCharges + "]";
	}
	
	
	
	

}
