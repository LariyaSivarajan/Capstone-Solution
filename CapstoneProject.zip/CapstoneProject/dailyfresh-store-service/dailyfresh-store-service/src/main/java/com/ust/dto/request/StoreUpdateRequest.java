package com.ust.dto.request;

import com.ust.model.Store;


public class StoreUpdateRequest {
	 Store store;

	 public Store getStore() {
	 	return store;
	 }

	 public void setStore(Store store) {
	 	this.store = store;
	 }
}
