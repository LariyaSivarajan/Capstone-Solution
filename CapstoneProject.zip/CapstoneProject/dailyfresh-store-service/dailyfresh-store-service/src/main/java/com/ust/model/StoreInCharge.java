package com.ust.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="storeincharges")
public class StoreInCharge {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int storeInChargeId;
	
	
	 @NotBlank(message = "In-charge name is required")
	    private String inChargeName;

	    @NotBlank(message = "Phone number is required")
	    @Pattern(regexp = "^\\d{10}$", message = "Phone number must be 10 digits")
	    private String inChargePhone;

		@JoinColumn(name="storeInChargeId",referencedColumnName = "storeId")
		@OneToOne(cascade =CascadeType.ALL)
		Store store;
	    
		public int getStoreInChargeId() {
			return storeInChargeId;
		}

		public void setStoreInChargeId(int storeInChargeId) {
			this.storeInChargeId = storeInChargeId;
		}

		public String getInChargeName() {
			return inChargeName;
		}

		public void setInChargeName(String inChargeName) {
			this.inChargeName = inChargeName;
		}

		public String getInChargePhone() {
			return inChargePhone;
		}

		public void setInChargePhone(String inChargePhone) {
			this.inChargePhone = inChargePhone;
		}

		public StoreInCharge() {
			super();
		}

		public StoreInCharge(int storeInChargeId, @NotBlank(message = "In-charge name is required") String inChargeName,
				@NotBlank(message = "Phone number is required") @Pattern(regexp = "^\\d{10}$", message = "Phone number must be 10 digits") String inChargePhone) {
			super();
			this.storeInChargeId = storeInChargeId;
			this.inChargeName = inChargeName;
			this.inChargePhone = inChargePhone;
		}

		@Override
		public String toString() {
			return "StoreInCharge [storeInChargeId=" + storeInChargeId + ", inChargeName=" + inChargeName
					+ ", inChargePhone=" + inChargePhone + "]";
		}

		@Override
		public int hashCode() {
			return Objects.hash(storeInChargeId);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StoreInCharge other = (StoreInCharge) obj;
			return storeInChargeId == other.storeInChargeId;
		}

		
	    
	    
	    

}
