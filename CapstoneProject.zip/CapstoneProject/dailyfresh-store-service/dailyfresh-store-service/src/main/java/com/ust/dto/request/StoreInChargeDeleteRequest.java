package com.ust.dto.request;


import com.ust.model.StoreInCharge;

public class StoreInChargeDeleteRequest {
	StoreInCharge storeInCharge;

	public StoreInCharge getStoreInCharge() {
		return storeInCharge;
	}

	public void setStoreInCharge(StoreInCharge storeInCharge) {
		this.storeInCharge = storeInCharge;
	}
  
  
  
}
