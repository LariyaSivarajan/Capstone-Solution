package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.StoreAddRequest;
import com.ust.dto.request.StoreDeleteRequest;
import com.ust.dto.request.StoreUpdateRequest;

import com.ust.dto.response.Store1ModifyResponse;
import com.ust.dto.response.StoreAddResponse;
import com.ust.dto.response.StoreDeleteResponse;
import com.ust.dto.response.StoreSearchResponse;
import com.ust.dto.response.StoreShowAllResponse;



import com.ust.exception.StoretNotFoundException;
import com.ust.model.Store;
import com.ust.service.StoreService;





@RestController
@RequestMapping(value = "/api")
public class StoreController {
	@Autowired
	StoreService service;

	@PostMapping(value = "/add")
	public ResponseEntity<StoreAddResponse> f1(@RequestBody StoreAddRequest request) {
		Store store1 = this.service.addNewStore(request.getStore());
		StoreAddResponse response = new StoreAddResponse();
		response.setStatusCode(200);
		response.setDescription("Store Added Successfully");
		response.setStore(store1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<Store1ModifyResponse> f2(@RequestBody StoreUpdateRequest request) {
		Store1ModifyResponse response = new Store1ModifyResponse();
		Store store1 = this.service.searchStore(request.getStore());
		if (store1 != null) {
			Store store2 = this.service.updateStore(request.getStore());

			response.setStatusCode(200);
			response.setDescription("Store Modified Successfully");
			response.setStore(store2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Store Not Found for Modification");
			response.setStore(null);
			return new ResponseEntity<Store1ModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{storid}")
	public ResponseEntity<StoreSearchResponse> f3(@PathVariable(name = "storid") int storid) throws Exception {
		StoreSearchResponse response = new StoreSearchResponse();
		Store store = this.service.searchStore(storid);
		if (store != null) {
			response.setStatusCode(200);
			response.setDescription("Store Fetched Successfully");
			response.setStore(store);
			return new ResponseEntity<StoreSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new StoretNotFoundException("Store Not Found");
			throw exception;
		}

		/*
		 * else { response.setStatusCode(404);
		 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
		 * return new
		 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
		 */

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<StoreShowAllResponse> f4() {
		List<Store> stores = this.service.getAllStores();
		StoreShowAllResponse response = new StoreShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Store Fetched");
		response.setStores(stores);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<StoreDeleteResponse> f5(@RequestBody StoreDeleteRequest request) {
		StoreDeleteResponse response = new StoreDeleteResponse();
		Store store1 = this.service.searchStore(request.getStore());
		if (store1 != null) {

			try {
				this.service.deleteStore(request.getStore());
				response.setStatusCode(200);
				response.setDescription("Store Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("Store Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Store Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	
}