package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.StoreAddRequest;
import com.ust.dto.request.StoreDeleteRequest;
import com.ust.dto.request.StoreInChargeAddRequest;
import com.ust.dto.request.StoreInChargeDeleteRequest;
import com.ust.dto.request.StoreInChargeUpdateRequest;
import com.ust.dto.request.StoreUpdateRequest;
import com.ust.dto.response.Store1ModifyResponse;
import com.ust.dto.response.StoreAddResponse;
import com.ust.dto.response.StoreDeleteResponse;
import com.ust.dto.response.StoreInChargeAddResponse;
import com.ust.dto.response.StoreInChargeDeleteResponse;
import com.ust.dto.response.StoreInChargeModifyResponse;
import com.ust.dto.response.StoreInChargeSearchResponse;
import com.ust.dto.response.StoreInChargeShowAllResponse;
import com.ust.dto.response.StoreSearchResponse;
import com.ust.dto.response.StoreShowAllResponse;
import com.ust.exception.StoretNotFoundException;
import com.ust.model.Store;
import com.ust.model.StoreInCharge;
import com.ust.service.StoreInChargeService;
import com.ust.service.StoreService;




@RestController
@RequestMapping(value = "/storeInChargeapi")
public class StoreInChargeController {
	
	@Autowired
	StoreInChargeService service;

	@PostMapping(value = "/add")
	public ResponseEntity<StoreInChargeAddResponse> f1(@RequestBody StoreInChargeAddRequest request) {
		StoreInCharge storeInCharge1 = this.service.addNewStoreInCharge(request.getStoreInCharge());
		StoreInChargeAddResponse response = new StoreInChargeAddResponse();
		response.setStatusCode(200);
		response.setDescription("StoreInCharge Added Successfully");
		response.setStoreInCharge(storeInCharge1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<StoreInChargeModifyResponse> f2(@RequestBody StoreInChargeUpdateRequest request) {
		StoreInChargeModifyResponse response = new StoreInChargeModifyResponse();
		StoreInCharge storeInCharge1 = this.service.searchStoreInCharge(request.getStoreInCharge());
		if (storeInCharge1 != null) {
			StoreInCharge storeInCharge2 = this.service.updateStoreInCharge(request.getStoreInCharge());

			response.setStatusCode(200);
			response.setDescription("StoreInCharge Modified Successfully");
			response.setStoreInCharge(storeInCharge2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("StoreInCharge Not Found for Modification");
			response.setStoreInCharge(null);
			return new ResponseEntity<StoreInChargeModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{storinid}")
	public ResponseEntity<StoreInChargeSearchResponse> f3(@PathVariable(name = "storinid") int storinid) throws Exception {
		StoreInChargeSearchResponse response = new StoreInChargeSearchResponse();
		StoreInCharge storeInCharge = this.service.searchStoreInCharge(storinid);
		if (storeInCharge != null) {
			response.setStatusCode(200);
			response.setDescription("StoreInCharge Fetched Successfully");
			response.setStoreInCharge(storeInCharge);
			return new ResponseEntity<StoreInChargeSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new StoretNotFoundException("StoreInCharge Not Found");
			throw exception;
		}

		/*
		 * else { response.setStatusCode(404);
		 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
		 * return new
		 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
		 */

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<StoreInChargeShowAllResponse> f4() {
		List<StoreInCharge> storeInCharges = this.service.getAllStoreInCharges();
		StoreInChargeShowAllResponse response = new StoreInChargeShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All StoreInCharge Fetched");
		response.setStoreInCharges(storeInCharges);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<StoreInChargeDeleteResponse> f5(@RequestBody StoreInChargeDeleteRequest request) {
		StoreInChargeDeleteResponse response = new StoreInChargeDeleteResponse();
		StoreInCharge storeInCharge1 = this.service.searchStoreInCharge(request.getStoreInCharge());
		if (storeInCharge1 != null) {

			try {
				this.service.deleteStoreInCharge(storeInCharge1);
				response.setStatusCode(200);
				response.setDescription("searchStoreInCharge Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("searchStoreInCharge Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("searchStoreInCharge Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	
}
