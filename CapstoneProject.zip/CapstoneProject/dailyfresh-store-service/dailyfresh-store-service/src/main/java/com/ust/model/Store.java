package com.ust.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="stores")
public class Store {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int storeId;

    @NotBlank(message = "Store address is required")
    private String storeAddress;

    @OneToOne(cascade =CascadeType.ALL)
	private StoreInCharge storeInCharge;

    @NotNull(message = "City ID is required")
    private int cityId;

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}

	public StoreInCharge getStoreInCharge() {
		return storeInCharge;
	}

	public void setStoreInCharge(StoreInCharge storeInCharge) {
		this.storeInCharge = storeInCharge;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public Store(int storeId, @NotBlank(message = "Store address is required") String storeAddress,
			StoreInCharge storeInCharge, @NotNull(message = "City ID is required") int cityId) {
		super();
		this.storeId = storeId;
		this.storeAddress = storeAddress;
		this.storeInCharge = storeInCharge;
		this.cityId = cityId;
	}

	public Store() {
		super();
	}

	@Override
	public String toString() {
		return "Store [storeId=" + storeId + ", storeAddress=" + storeAddress + ", storeInCharge=" + storeInCharge
				+ ", cityId=" + cityId + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(storeId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Store other = (Store) obj;
		return storeId == other.storeId;
	}

	

	
    

	

	


	    

}
