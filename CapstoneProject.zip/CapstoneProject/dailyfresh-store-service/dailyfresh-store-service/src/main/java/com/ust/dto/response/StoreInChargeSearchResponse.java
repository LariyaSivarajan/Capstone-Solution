package com.ust.dto.response;

import com.ust.model.StoreInCharge;


public class StoreInChargeSearchResponse {
	int statusCode;
	String description;
	StoreInCharge storeInCharge;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public StoreInCharge getStoreInCharge() {
		return storeInCharge;
	}
	public void setStoreInCharge(StoreInCharge storeInCharge) {
		this.storeInCharge = storeInCharge;
	}
	@Override
	public String toString() {
		return "StoreInChargeSearchResponse [statusCode=" + statusCode + ", description=" + description
				+ ", storeInCharge=" + storeInCharge + "]";
	}
	
	
	
}
