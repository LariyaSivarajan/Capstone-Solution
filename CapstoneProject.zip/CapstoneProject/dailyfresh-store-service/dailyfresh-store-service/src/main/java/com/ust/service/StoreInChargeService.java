package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.StoreInChargeRepository;

import com.ust.model.StoreInCharge;


@Service
public class StoreInChargeService  {
	
@Autowired
StoreInChargeRepository repo;
	public StoreInCharge addNewStoreInCharge(StoreInCharge storeInCharge) {
		return repo.save(storeInCharge);
	}
	
	public StoreInCharge updateStoreInCharge(StoreInCharge storeInCharge) {
		return repo.save(storeInCharge);
		
	}
public StoreInCharge searchStoreInCharge(StoreInCharge storeInCharge) {
	  Optional<StoreInCharge> optional=repo.findById(storeInCharge.getStoreInChargeId());
	  
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}

public StoreInCharge searchStoreInCharge(int id) {
	  Optional<StoreInCharge> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}
public List<StoreInCharge> getAllStoreInCharges(){
	  return repo.findAll();
}
public boolean deleteStoreInCharge(StoreInCharge storeInCharge) {
	  repo.delete(storeInCharge);
	  return true;
}
}