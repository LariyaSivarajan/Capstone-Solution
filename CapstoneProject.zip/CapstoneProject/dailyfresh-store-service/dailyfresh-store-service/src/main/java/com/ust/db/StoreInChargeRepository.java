package com.ust.db;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.model.StoreInCharge;


@Repository
public interface StoreInChargeRepository extends JpaRepository<StoreInCharge, Integer>{
	//List<Supplier> findByContact_supplierName(String supplierName);
	 // List<Supplier> findBy_supplierCity(String supplierCity);
}
