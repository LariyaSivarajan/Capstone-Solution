package com.ust.dto.response;


import com.ust.model.Store;
import com.ust.model.StoreInCharge;


public class Store1ModifyResponse {
	@Override
	public String toString() {
		return "Store1ModifyResponse [statusCode=" + statusCode + ", description=" + description + ", store=" + store
				+ "]";
	}
	public Store getStore() {
		return store;
	}
	public void setStore(Store store) {
		this.store = store;
	}
	int statusCode;
	String description;
	Store store;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
