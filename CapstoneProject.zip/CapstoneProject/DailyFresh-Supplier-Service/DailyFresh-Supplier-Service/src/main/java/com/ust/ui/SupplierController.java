package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.SupplierAddRequest;
import com.ust.dto.request.SupplierDeleteRequest;
import com.ust.dto.request.SupplierUpdateRequest;
import com.ust.dto.response.SupplierAddResponse;
import com.ust.dto.response.SupplierDeleteResponse;
import com.ust.dto.response.SupplierModifyResponse;
import com.ust.dto.response.SupplierSearchResponse;
import com.ust.dto.response.SupplierShowAllByContactNameResponse;
import com.ust.dto.response.SupplierShowAllResponse;
import com.ust.dto.response.SupplierShowSupplierCityResponse;
import com.ust.dto.response.SupplierShowSupplierCityResponse;
import com.ust.exception.SupplierNotFoundException;
import com.ust.model.Supplier;
import com.ust.service.SupplierService;




@RestController
@RequestMapping(value = "/api")
public class SupplierController {
	@Autowired
	SupplierService service;

	@PostMapping(value = "/add")
	public ResponseEntity<SupplierAddResponse> f1(@RequestBody SupplierAddRequest request) {
		Supplier supplier1 = this.service.addNewSupplier(request.getSupplier());
		SupplierAddResponse response = new SupplierAddResponse();
		response.setStatusCode(200);
		response.setDescription("Supplier Added Successfully");
		response.setSupplier(supplier1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<SupplierModifyResponse> f2(@RequestBody SupplierUpdateRequest request) {
		SupplierModifyResponse response = new SupplierModifyResponse();
		Supplier supplier1 = this.service.searchSupplier(request.getSupplier());
		if (supplier1 != null) {
			Supplier supplier2 = this.service.updateSupplier(request.getSupplier());

			response.setStatusCode(200);
			response.setDescription("Supplier Modified Successfully");
			response.setSupplier(supplier2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Supplier Not Found for Modification");
			response.setSupplier(null);
			return new ResponseEntity<SupplierModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{suppid}")
	public ResponseEntity<SupplierSearchResponse> f3(@PathVariable(name = "suppid") int suppid) throws Exception {
		SupplierSearchResponse response = new SupplierSearchResponse();
		Supplier supplier = this.service.searchSupplier(suppid);
		if (supplier != null) {
			response.setStatusCode(200);
			response.setDescription("Supplier Fetched Successfully");
			response.setSupplier(supplier);
			return new ResponseEntity<SupplierSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new SupplierNotFoundException("Supplier Not Found");
			throw exception;
		}

		/*
		 * else { response.setStatusCode(404);
		 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
		 * return new
		 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
		 */

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<SupplierShowAllResponse> f4() {
		List<Supplier> suppliers = this.service.getAllSuppliers();
		SupplierShowAllResponse response = new SupplierShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All Customers Fetched");
		response.setSuppliers(suppliers);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<SupplierDeleteResponse> f5(@RequestBody SupplierDeleteRequest request) {
		SupplierDeleteResponse response = new SupplierDeleteResponse();
		Supplier supplier1 = this.service.searchSupplier(request.getSupplier());
		if (supplier1 != null) {

			try {
				this.service.deleteSupplier(request.getSupplier());
				response.setStatusCode(200);
				response.setDescription("Supplier Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription("Supplier Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Supplier Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}

	/*@GetMapping(value = "/showAllBySupplierName/{name}")
	public ResponseEntity<SupplierShowAllByContactNameResponse> f6(@PathVariable(name = "name") String supplierName) {
		SupplierShowAllByContactNameResponse response = new SupplierShowAllByContactNameResponse();
		List<Supplier> suppliersBySameName = this.service.getSuppliersByName(supplierName);
		if (suppliersBySameName.isEmpty()) {
			response.setStatusCode(200);
			response.setDescription("There are no Suppliers by same name" + supplierName);
			response.setSuppliers(suppliersBySameName);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + suppliersBySameName.size() + "with same Name" + supplierName);
			response.setSuppliers(suppliersBySameName);
		}
		return ResponseEntity.ok(response);
	}

	@GetMapping(value = "/showAllBySupplierCity", produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<SupplierShowSupplierCityResponse> f7(@RequestParam(name = "txt_city") String supplierCity) {
		SupplierShowSupplierCityResponse response = new SupplierShowSupplierCityResponse();
		List<Supplier> supplierByCity = this.service.getSuppliersByCity(supplierCity);
		if (supplierByCity!=null) {
			response.setStatusCode(200);
			response.setDescription("There are no suppliers having same phone number" + supplierCity);
			response.setSuppliers(supplierByCity);
		} else {
			response.setStatusCode(200);
			response.setDescription("There are" + supplierByCity + "with same phone number" + supplierCity);
			response.setSuppliers(supplierByCity);
		}
		return ResponseEntity.ok(response);
	}*/
}