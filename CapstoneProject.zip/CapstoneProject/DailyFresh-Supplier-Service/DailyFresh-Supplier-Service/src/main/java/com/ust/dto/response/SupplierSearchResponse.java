package com.ust.dto.response;

import com.ust.model.Supplier;

public class SupplierSearchResponse {
	int statusCode;
	String description;
	Supplier supplier;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	@Override
	public String toString() {
		return "SupplierSearchResponse [statusCode=" + statusCode + ", description=" + description + ", supplier="
				+ supplier + "]";
	}
	
	
}
