package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.ContactAddRequest;
import com.ust.dto.request.ContactDeleteRequest;
import com.ust.dto.request.ContactUpdateRequest;
import com.ust.dto.request.SupplierAddRequest;
import com.ust.dto.request.SupplierDeleteRequest;
import com.ust.dto.request.SupplierUpdateRequest;
import com.ust.dto.response.ContactAddResponse;
import com.ust.dto.response.ContactDeleteResponse;
import com.ust.dto.response.ContactModifyResponse;
import com.ust.dto.response.ContactSearchResponse;
import com.ust.dto.response.ContactShowAllResponse;
import com.ust.dto.response.SupplierAddResponse;
import com.ust.dto.response.SupplierDeleteResponse;
import com.ust.dto.response.SupplierModifyResponse;
import com.ust.dto.response.SupplierSearchResponse;
import com.ust.dto.response.SupplierShowAllResponse;
import com.ust.exception.ContactNotFoundException;
import com.ust.exception.SupplierNotFoundException;
import com.ust.model.Contact;
import com.ust.model.Supplier;
import com.ust.service.ContactService;

@RestController
@RequestMapping(value = "/contactapi")
public class ContactController {
	
@Autowired
ContactService service;

@PostMapping(value = "/add")
public ResponseEntity<ContactAddResponse> f1(@RequestBody ContactAddRequest request) {
	Contact contact1 = this.service.addNewContact(request.getContact());
	ContactAddResponse response = new ContactAddResponse();
	response.setStatusCode(200);
	response.setDescription("Contact Added Successfully");
	response.setContact(contact1);
	return new ResponseEntity<>(response, HttpStatus.CREATED);

}

@PutMapping(value = "/modify")
public ResponseEntity<ContactModifyResponse> f2(@RequestBody ContactUpdateRequest request) {
	ContactModifyResponse response = new ContactModifyResponse();
	Contact contact1 = this.service.searchContact(request.getContact());
	if (contact1 != null) {
		Contact contact2 = this.service.updateContact(request.getContact());

		response.setStatusCode(200);
		response.setDescription("Contact Modified Successfully");
		response.setContact(contact2);
		return ResponseEntity.ok(response);
	} else {
		response.setStatusCode(404);
		response.setDescription("Contact Not Found for Modification");
		response.setContact(null);
		return new ResponseEntity<ContactModifyResponse>(response, HttpStatus.NOT_FOUND);
	}

	// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
}

@GetMapping(value = "/find/{contactid}")
public ResponseEntity<ContactSearchResponse> f3(@PathVariable(name = "contactid") int contactid) throws Exception {
	ContactSearchResponse response = new ContactSearchResponse();
	Contact contact = this.service.searchContact(contactid);
	if (contact != null) {
		response.setStatusCode(200);
		response.setDescription("Contact Fetched Successfully");
		response.setContact(contact);;
		return new ResponseEntity<ContactSearchResponse>(response, HttpStatus.OK);
	} else {
		Exception exception = new ContactNotFoundException("Contact Not Found");
		throw exception;
	}

	/*
	 * else { response.setStatusCode(404);
	 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
	 * return new
	 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
	 */

}

@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
public ResponseEntity<ContactShowAllResponse> f4() {
	List<Contact> contacts = this.service.getAllContacts();
	ContactShowAllResponse response = new ContactShowAllResponse();
	response.setStatusCode(200);
	response.setDescription("All Customers Fetched");
	response.setContacts(contacts);
	return ResponseEntity.ok(response);
}

@DeleteMapping(value = "/delete")
public ResponseEntity<ContactDeleteResponse> f5(@RequestBody ContactDeleteRequest request) {
	ContactDeleteResponse response = new ContactDeleteResponse();
	Contact contact1 = this.service.searchContact(request.getContact());
	if (contact1 != null) {

		try {
			this.service.deleteContact(request.getContact());
			response.setStatusCode(200);
			response.setDescription("Contact Deleted Successfully");
			response.setDeleteStatus(true);
			return ResponseEntity.ok().body(response);

		} catch (Exception e) {
			// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
			response.setStatusCode(500);
			response.setDescription("Contact Not Deleted");
			response.setDeleteStatus(false);
			return ResponseEntity.internalServerError().body(response);
		}
	} else {
		response.setStatusCode(404);
		response.setDescription("Supplier Not Found");
		response.setDeleteStatus(false);
		return new ResponseEntity(response, HttpStatus.NOT_FOUND);
	}
}
	
}
