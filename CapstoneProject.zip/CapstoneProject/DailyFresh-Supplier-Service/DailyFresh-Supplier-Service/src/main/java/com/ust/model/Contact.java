package com.ust.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="contacts")

public class Contact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private int contactId;
	
	@Column
	//@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	//@Size(min=3,max=50, message="Length of name should be between 3 to 50")
	String contactPersonName;
	
	@Column
	//@Pattern(regexp="^[0-9]{10}$",message="Length of phone should be 10")
	String contactPhoneNumber;
	
	@Column
	//@Email(message="Please enter valid email")
	private String contactEmail;
	@JoinColumn(name="contactId",referencedColumnName = "supplierId")
	@OneToOne(cascade =CascadeType.ALL)
	Supplier supplier;

	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}
	public void setContactPhoneNumber(String contactPhoneNumber) {
		this.contactPhoneNumber = contactPhoneNumber;
	}
	public String getContactEmail() {
		return contactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public Contact(int contactId, String contactPersonName, String contactPhoneNumber, String contactEmail,
			Supplier supplier) {
		super();
		this.contactId = contactId;
		this.contactPersonName = contactPersonName;
		this.contactPhoneNumber = contactPhoneNumber;
		this.contactEmail = contactEmail;
		this.supplier = supplier;
	}
	public Contact() {
		super();
	}
	@Override
	public String toString() {
		return "Contact [contactId=" + contactId + ", contactPersonName=" + contactPersonName + ", contactPhoneNumber="
				+ contactPhoneNumber + ", contactEmail=" + contactEmail + ", supplier=" + supplier + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(contactId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		return contactId == other.contactId;
	}
	
	
	
	
	
}
