package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.ContactRepository;
import com.ust.model.Contact;
import com.ust.model.Supplier;

@Service
public class ContactService  {
	
@Autowired
ContactRepository repo;
	public Contact addNewContact(Contact contact) {
		return repo.save(contact);
	}
	
	public Contact updateContact(Contact contact) {
		return repo.save(contact);
		
	}
public Contact searchContact(Contact contact) {
	  Optional<Contact> optional=repo.findById(contact.getContactId());
	  
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}

public Contact searchContact(int id) {
	  Optional<Contact> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}
public List<Contact> getAllContacts(){
	  return repo.findAll();
}
public boolean deleteContact(Contact contact) {
	  repo.delete(contact);
	  return true;
}
}