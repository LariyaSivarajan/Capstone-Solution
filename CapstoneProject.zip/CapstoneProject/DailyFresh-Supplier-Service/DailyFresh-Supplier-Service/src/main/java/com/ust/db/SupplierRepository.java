package com.ust.db;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.model.Supplier;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, Integer>{
	//List<Supplier> findByContact_supplierName(String supplierName);
	 // List<Supplier> findBy_supplierCity(String supplierCity);
}
