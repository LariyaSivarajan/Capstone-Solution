package com.ust.dto.response;

import java.util.List;


import com.ust.model.Supplier;


public class SupplierShowAllResponse {
	int statusCode;
	String description;
	List<Supplier> suppliers;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<Supplier> getSuppliers() {
		return suppliers;
	}
	public void setSuppliers(List<Supplier> suppliers) {
		this.suppliers = suppliers;
	}
	@Override
	public String toString() {
		return "SupplierShowAllResponse [statusCode=" + statusCode + ", description=" + description + ", suppliers="
				+ suppliers + "]";
	}
	
	

}
