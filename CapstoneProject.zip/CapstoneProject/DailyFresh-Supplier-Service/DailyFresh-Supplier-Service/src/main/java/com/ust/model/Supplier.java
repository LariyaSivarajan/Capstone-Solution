package com.ust.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name="suppliers")

public class Supplier {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private int supplierId;
	
	@Column
	@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of name should be between 3 to 20")
	String supplierName;
	
	@Column
	@NotEmpty(message="City is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of city should be between 3 to 20")
	private String supplierCity;

	
	
	@OneToOne(cascade =CascadeType.ALL)
	private Contact contact;



	public int getSupplierId() {
		return supplierId;
	}



	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}



	public String getSupplierName() {
		return supplierName;
	}



	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}



	public String getSupplierCity() {
		return supplierCity;
	}



	public void setSupplierCity(String supplierCity) {
		this.supplierCity = supplierCity;
	}



	public Contact getContact() {
		return contact;
	}



	public void setContact(Contact contact) {
		this.contact = contact;
	}



	public Supplier(int supplierId,
			@NotEmpty(message = "Name is mandatory.....Cannot be left blank") @Size(min = 3, max = 20, message = "Length of name should be between 3 to 20") String supplierName,
			@NotEmpty(message = "City is mandatory.....Cannot be left blank") @Size(min = 3, max = 20, message = "Length of city should be between 3 to 20") String supplierCity,
			Contact contact) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierCity = supplierCity;
		this.contact = contact;
	}



	public Supplier() {
		super();
	}



	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", supplierName=" + supplierName + ", supplierCity="
				+ supplierCity + ", contact=" + contact + "]";
	}



	@Override
	public int hashCode() {
		return Objects.hash(supplierId);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Supplier other = (Supplier) obj;
		return supplierId == other.supplierId;
	}
	
	
	
}
