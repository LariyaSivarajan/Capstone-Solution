package com.ust.dto.request;

import com.ust.model.OrderItem;


public class OredrItemUpdateRequest {
	 OrderItem orderItem;

	 public OrderItem getOrderItem() {
	 	return orderItem;
	 }

	 public void setOrderItem(OrderItem orderItem) {
	 	this.orderItem = orderItem;
	 }


}
