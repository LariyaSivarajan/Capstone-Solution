package com.ust.model;

import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@Entity
@Table(name="orderItems")

public class OrderItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int orderItemId;
	
	@Column
	@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	@Size(min=3,max=50, message="Length of name should be between 3 to 50")
	String Name;
	
	@Column
	@NotNull(message = "quantity is required")
	int  quantity;
	
	@Column
	@NotNull(message = "price amount is required")
	@DecimalMin(value = "0.01", message = "price amount must be greater than zero")
	private double price;

	public int getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(int orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public OrderItem(int orderItemId,
			@NotEmpty(message = "Name is mandatory.....Cannot be left blank") @Size(min = 3, max = 50, message = "Length of name should be between 3 to 50") String name,
			@NotNull(message = "quantity is required") int quantity,
			@NotNull(message = "price amount is required") @DecimalMin(value = "0.01", message = "price amount must be greater than zero") double price) {
		super();
		this.orderItemId = orderItemId;
		Name = name;
		this.quantity = quantity;
		this.price = price;
	}

	public OrderItem() {
		super();
	}

	@Override
	public String toString() {
		return "OrderItem [orderItemId=" + orderItemId + ", Name=" + Name + ", quantity=" + quantity + ", price="
				+ price + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderItemId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderItem other = (OrderItem) obj;
		return orderItemId == other.orderItemId;
	}

	
	
	
	
}
