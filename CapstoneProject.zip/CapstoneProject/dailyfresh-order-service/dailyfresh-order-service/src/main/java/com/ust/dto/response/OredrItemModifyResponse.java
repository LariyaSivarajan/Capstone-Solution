package com.ust.dto.response;


import com.ust.model.OrderItem;


public class OredrItemModifyResponse {
	int statusCode;
	String description;
	OrderItem orderItem;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public OrderItem getOrderItem() {
		return orderItem;
	}
	public void setOrderItem(OrderItem orderItem) {
		this.orderItem = orderItem;
	}
	@Override
	public String toString() {
		return "OrderItemModifyResponse [statusCode=" + statusCode + ", description=" + description + ", orderItem="
				+ orderItem + "]";
	}
	
	
}
