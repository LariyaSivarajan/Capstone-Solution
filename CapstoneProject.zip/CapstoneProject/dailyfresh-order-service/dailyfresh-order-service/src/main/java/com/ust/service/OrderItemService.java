package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.db.OrderItemRepository;

import com.ust.model.OrderItem;



@Service
public class OrderItemService {
 @Autowired
 OrderItemRepository repo;
 public OrderItem addNewOrderItem(OrderItem orderItem) {
		return repo.save(orderItem);
	}
	
	public OrderItem updateOrderItem(OrderItem orderItem) {
		return repo.save(orderItem);
		
	}
public OrderItem searchOrderItem(OrderItem orderItem) {
	  Optional<OrderItem> optional=repo.findById(orderItem.getOrderItemId());
	  
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}

public OrderItem searchOrderItem(int id) {
	  Optional<OrderItem> optional=repo.findById(id);
	  if(optional.isPresent())
		  return optional.get();
	  else
		  return null;
}
public List<OrderItem> getAllOrderItems(){
	  return repo.findAll();
}
public boolean deleteOrderItem(OrderItem orderItem) {
	  repo.delete(orderItem);
	  return true;
}

/*public List<Supplier> getSuppliersByName(String supplierName){
	 return repo.findByContact_supplierName(supplierName);
}
public List<Supplier> getSuppliersByCity(String supplierCity){
	 return repo.findBy_supplierCity(supplierCity);
}*/
}
