package com.ust.model;

import java.time.LocalDateTime;
import java.util.Objects;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@Entity
@Table(name="orders")

public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int orderId;
	
	@Column
	 @NotNull(message = "Order date must not be null")
   private LocalDateTime orderDate;
	
	@ManyToOne // ✅ This tells Hibernate it's a relationship
    @JoinColumn(name = "orderItemId") // ✅ Optional but good for clarity
    private OrderItem orderItem;
	
	
	@Column
	@NotEmpty(message="Location is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of location should be between 3 to 20")
	private String deliveryLocation;
	
	@Column
	@NotNull(message = "Order amount is required")
	@DecimalMin(value = "0.01", message = "Bill amount must be greater than zero")
	private double orderAmount;

	@Override
	public int hashCode() {
		return Objects.hash(orderId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return orderId == other.orderId;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", orderItem=" + orderItem
				+ ", deliveryLocation=" + deliveryLocation + ", orderAmount=" + orderAmount + "]";
	}

	public Order() {
		super();
	}

	public Order(int orderId, @NotNull(message = "Order date must not be null") LocalDateTime orderDate,
			OrderItem orderItem,
			@NotEmpty(message = "Location is mandatory.....Cannot be left blank") @Size(min = 3, max = 20, message = "Length of location should be between 3 to 20") String deliveryLocation,
			@NotNull(message = "Order amount is required") @DecimalMin(value = "0.01", message = "Bill amount must be greater than zero") double orderAmount) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.orderItem = orderItem;
		this.deliveryLocation = deliveryLocation;
		this.orderAmount = orderAmount;
	}
	
	
	

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public OrderItem getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(OrderItem orderItem) {
		this.orderItem = orderItem;
	}

	public String getDeliveryLocation() {
		return deliveryLocation;
	}

	public void setDeliveryLocation(String deliveryLocation) {
		this.deliveryLocation = deliveryLocation;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	
	
	
	
	
}
