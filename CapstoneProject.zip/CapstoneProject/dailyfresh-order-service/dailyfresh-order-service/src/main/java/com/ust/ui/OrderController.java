package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.OrderAddRequest;
import com.ust.dto.request.OrderDeleteRequest;
import com.ust.dto.request.OrderUpdateRequest;
import com.ust.dto.response.OrderAddResponse;
import com.ust.dto.response.OrderDeleteResponse;
import com.ust.dto.response.OrderModifyResponse;
import com.ust.dto.response.OrderSearchResponse;
import com.ust.dto.response.OrderShowAllResponse;
import com.ust.exception.OrderNotFoundException;
import com.ust.model.Order;
import com.ust.service.OrderService;





@RestController
@RequestMapping(value = "/api")
public class OrderController {
	@Autowired
	 OrderService service;

	@PostMapping(value = "/add")
	public ResponseEntity< OrderAddResponse> f1(@RequestBody  OrderAddRequest request) {
		 Order  order1 = this.service.addNewOrder(request.getOredr());
		 OrderAddResponse response = new  OrderAddResponse();
		response.setStatusCode(200);
		response.setDescription("Order Added Successfully");
		response.setOrder(order1);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

	@PutMapping(value = "/modify")
	public ResponseEntity<OrderModifyResponse> f2(@RequestBody  OrderUpdateRequest request) {
		 OrderModifyResponse response = new  OrderModifyResponse();
		 Order  order1 = this.service.searchOrder(request.getOredr());
		if (order1 != null) {
			 Order  order2 = this.service.updateOrder(request.getOredr());

			response.setStatusCode(200);
			response.setDescription("Order Modified Successfully");
			response.setOrder(order2);
			return ResponseEntity.ok(response);
		} else {
			response.setStatusCode(404);
			response.setDescription("Order Not Found for Modification");
			response.setOrder(null);
			return new ResponseEntity<OrderModifyResponse>(response, HttpStatus.NOT_FOUND);
		}

		// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{orderid}")
	public ResponseEntity<OrderSearchResponse> f3(@PathVariable(name = "orderid") int orderid) throws Exception {
		 OrderSearchResponse response = new  OrderSearchResponse();
		 Order  order = this.service.searchOrder(orderid);
		if (order != null) {
			response.setStatusCode(200);
			response.setDescription("Order Fetched Successfully");
			response.setOrder(order);
			return new ResponseEntity<OrderSearchResponse>(response, HttpStatus.OK);
		} else {
			Exception exception = new  OrderNotFoundException("Order Not Found");
			throw exception;
		}

		/*
		 * else { response.setStatusCode(404);
		 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
		 * return new
		 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
		 */

	}

	@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<OrderShowAllResponse> f4() {
		List<Order>  orders = this.service.getAllOrders();
		 OrderShowAllResponse response = new  OrderShowAllResponse();
		response.setStatusCode(200);
		response.setDescription("All  Orders Fetched");
		response.setOrders(orders);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping(value = "/delete")
	public ResponseEntity<OrderDeleteResponse> f5(@RequestBody  OrderDeleteRequest request) {
		 OrderDeleteResponse response = new  OrderDeleteResponse();
		 Order order1 = this.service.searchOrder(request.getOredr());
		if (order1 != null) {

			try {
				this.service.deleteOrder(request.getOredr());
				response.setStatusCode(200);
				response.setDescription(" Order Deleted Successfully");
				response.setDeleteStatus(true);
				return ResponseEntity.ok().body(response);

			} catch (Exception e) {
				// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
				response.setStatusCode(500);
				response.setDescription(" Order Not Deleted");
				response.setDeleteStatus(false);
				return ResponseEntity.internalServerError().body(response);
			}
		} else {
			response.setStatusCode(404);
			response.setDescription("Order Not Found");
			response.setDeleteStatus(false);
			return new ResponseEntity(response, HttpStatus.NOT_FOUND);
		}
	}


}