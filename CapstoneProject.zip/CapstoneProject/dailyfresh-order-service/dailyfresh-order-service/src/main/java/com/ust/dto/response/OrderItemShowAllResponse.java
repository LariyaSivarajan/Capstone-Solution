package com.ust.dto.response;

import java.util.List;

import com.ust.model.OrderItem;


public class OrderItemShowAllResponse {
	int statusCode;
	String description;
	List<OrderItem> orderItems;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<OrderItem> getOrderItems() {
		return orderItems;
	}
	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}
	@Override
	public String toString() {
		return "OrderItemShowAllResponse [statusCode=" + statusCode + ", description=" + description + ", orderItems="
				+ orderItems + "]";
	}
	
	
	
	
}
