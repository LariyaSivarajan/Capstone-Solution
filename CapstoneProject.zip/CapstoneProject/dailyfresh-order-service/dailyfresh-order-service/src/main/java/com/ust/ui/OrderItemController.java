package com.ust.ui;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.request.OrderItemAddRequest;
import com.ust.dto.request.OrderItemDeleteRequest;
import com.ust.dto.request.OredrItemUpdateRequest;
import com.ust.dto.response.OrderItemAddResponse;
import com.ust.dto.response.OrderItemDeleteResponse;
import com.ust.dto.response.OrderItemModifyResponse;
import com.ust.dto.response.OrderItemSearchResponse;
import com.ust.dto.response.OrderItemShowAllResponse;
import com.ust.exception.OrderItemNotFoundException;
import com.ust.model.OrderItem;
import com.ust.service.OrderItemService;


@RestController
@RequestMapping(value = "/contactapi")
public class OrderItemController {
	
@Autowired
OrderItemService service;

@PostMapping(value = "/add")
public ResponseEntity<OrderItemAddResponse> f1(@RequestBody OrderItemAddRequest request) {
	OrderItem orderItem1 = this.service.addNewOrderItem(request.getOrderItem());
	OrderItemAddResponse response = new OrderItemAddResponse();
	response.setStatusCode(200);
	response.setDescription("OrderItem Added Successfully");
	response.setOrderItem(orderItem1);
	return new ResponseEntity<>(response, HttpStatus.CREATED);

}

@PutMapping(value = "/modify")
public ResponseEntity<OrderItemModifyResponse> f2(@RequestBody OredrItemUpdateRequest request) {
	OrderItemModifyResponse response = new OrderItemModifyResponse();
	OrderItem orderItem1 = this.service.searchOrderItem(request.getOrderItem());
	if (orderItem1 != null) {
		OrderItem orderItem2 = this.service.updateOrderItem(request.getOrderItem());

		response.setStatusCode(200);
		response.setDescription("OrderItem Modified Successfully");
		response.setOrderItem(orderItem2);
		return ResponseEntity.ok(response);
	} else {
		response.setStatusCode(404);
		response.setDescription("OrderItem Not Found for Modification");
		response.setOrderItem(null);
		return new ResponseEntity<OrderItemModifyResponse>(response, HttpStatus.NOT_FOUND);
	}

	// return new ResponseEntity<Visitor>(visitor1, HttpStatus.OK);
}

@GetMapping(value = "/find/{oritemid}")
public ResponseEntity<OrderItemSearchResponse> f3(@PathVariable(name = "oritemid") int oritemid) throws Exception {
	OrderItemSearchResponse response = new OrderItemSearchResponse();
	OrderItem orderItem = this.service.searchOrderItem(oritemid);
	if (orderItem != null) {
		response.setStatusCode(200);
		response.setDescription("OrderItem Fetched Successfully");
		response.setOrderItem(orderItem);;
		return new ResponseEntity<OrderItemSearchResponse>(response, HttpStatus.OK);
	} else {
		Exception exception = new OrderItemNotFoundException("OrderItem Not Found");
		throw exception;
	}

	/*
	 * else { response.setStatusCode(404);
	 * response.setDescription("Visitor Not Found"); response.setVisitor(null);
	 * return new
	 * ResponseEntity<VisitorSearchResponse>(response,HttpStatus.NOT_FOUND); }
	 */

}

@GetMapping(value = "/showAll", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
public ResponseEntity<OrderItemShowAllResponse> f4() {
	List<OrderItem> orderItems = this.service.getAllOrderItems();
	OrderItemShowAllResponse response = new OrderItemShowAllResponse();
	response.setStatusCode(200);
	response.setDescription("All OrderItem Fetched");
	response.setOrderItems(orderItems);
	return ResponseEntity.ok(response);
}

@DeleteMapping(value = "/delete")
public ResponseEntity<OrderItemDeleteResponse> f5(@RequestBody OrderItemDeleteRequest request) {
	OrderItemDeleteResponse response = new OrderItemDeleteResponse();
	OrderItem orderItem1 = this.service.searchOrderItem(request.getOrderItem());
	if (orderItem1 != null) {

		try {
			this.service.deleteOrderItem(request.getOrderItem());
			response.setStatusCode(200);
			response.setDescription("OrderItem Deleted Successfully");
			response.setDeleteStatus(true);
			return ResponseEntity.ok().body(response);

		} catch (Exception e) {
			// return new ResponseEntity<Boolean>(true,HttpStatus.OK);
			response.setStatusCode(500);
			response.setDescription("OrderItem Not Deleted");
			response.setDeleteStatus(false);
			return ResponseEntity.internalServerError().body(response);
		}
	} else {
		response.setStatusCode(404);
		response.setDescription("OrderItem Not Found");
		response.setDeleteStatus(false);
		return new ResponseEntity(response, HttpStatus.NOT_FOUND);
	}
}
	
}
