package com.ust.dto.request;


import com.ust.model.Order;

public class OrderAddRequest {
  Order order;

public Order getOredr() {
	return order;
}

public void setOredr(Order oredr) {
	this.order = order;
}


  
  
}
