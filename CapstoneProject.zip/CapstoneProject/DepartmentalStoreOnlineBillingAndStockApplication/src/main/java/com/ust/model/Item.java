package com.ust.model;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
	@Table(name="items")

	public class Item {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@EqualsAndHashCode.Include
		@Column
		private int itemId;
		
		@NotNull(message="Item Name is mandatory.....")
		//@Size(min=3,max=100, message="Length of name should be between 3 to 100 characters")
		@Column
		private String itemName;
		
		@NotNull(message="Category is mandatory.....")	
		//@Size(min=3,max=100, message="Length of name should be between 3 to 100 characters")    
		@Column
		private String category;
		
		
		@NotNull(message="Purchase price cannot be null")	
	    @Min(value=0 ,message="Purchase price must be greater than or equal to zero")	   
		@Column
		private double  purchasePrice;


		@NotNull(message="Selling price cannot be null")	
	   @Min(value=0 ,message="Selling  price must be greater than or equal to zero")	    
		@Column
		private double  sellingPrice;


		public Item() {
			super();
			// TODO Auto-generated constructor stub
		}


		public Item(int itemId, @NotNull(message = "Item Name is mandatory.....") String itemName,
				@NotNull(message = "Category is mandatory.....") String category,
				@NotNull(message = "Purchase price cannot be null") @Min(value = 0, message = "Purchase price must be greater than or equal to zero") double purchasePrice,
				@NotNull(message = "Selling price cannot be null") @Min(value = 0, message = "Selling  price must be greater than or equal to zero") double sellingPrice) {
			super();
			this.itemId = itemId;
			this.itemName = itemName;
			this.category = category;
			this.purchasePrice = purchasePrice;
			this.sellingPrice = sellingPrice;
		}


		public int getItemId() {
			return itemId;
		}


		public void setItemId(int itemId) {
			this.itemId = itemId;
		}


		public String getItemName() {
			return itemName;
		}


		public void setItemName(String itemName) {
			this.itemName = itemName;
		}


		public String getCategory() {
			return category;
		}


		public void setCategory(String category) {
			this.category = category;
		}


		public double getPurchasePrice() {
			return purchasePrice;
		}


		public void setPurchasePrice(double purchasePrice) {
			this.purchasePrice = purchasePrice;
		}


		public double getSellingPrice() {
			return sellingPrice;
		}


		public void setSellingPrice(double sellingPrice) {
			this.sellingPrice = sellingPrice;
		}


		@Override
		public String toString() {
			return "Item [itemId=" + itemId + ", itemName=" + itemName + ", category=" + category + ", purchasePrice="
					+ purchasePrice + ", sellingPrice=" + sellingPrice + "]";
		}


		@Override
		public int hashCode() {
			return Objects.hash(itemId);
		}


		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Item other = (Item) obj;
			return itemId == other.itemId;
		}


		


		
		
		}

		