package com.ust.db;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.City;
import com.ust.model.Item;
import com.ust.model.Location;
import com.ust.model.Stock;
 
public interface StockRepository extends JpaRepository<Stock, Long>{
	 Optional<Stock> findByItemAndLocationAndCity(Item item, Location location, City city);
	 Optional<Stock> findByItem(Item item);
	 Optional<Stock> findByLocation(Location location);
	 Optional<Stock> findByCity(City city);

 
}