package com.ust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DepartmentalStoreOnlineBillingAndStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentalStoreOnlineBillingAndStockApplication.class, args);
	}

}
