package com.ust.db;


import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Location;
public interface LocationRepository extends JpaRepository<Location, Long>{
	 
}