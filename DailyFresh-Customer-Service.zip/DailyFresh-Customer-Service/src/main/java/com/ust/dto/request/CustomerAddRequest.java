package com.ust.dto.request;

import com.ust.model.Customer;


public class CustomerAddRequest {
 Customer customer;

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}


 
}
