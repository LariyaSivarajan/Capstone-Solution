package com.ust.model;

import org.springframework.beans.factory.annotation.Autowired;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Table(name="customers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@EqualsAndHashCode.Include
	private int customerId;
	
	@Column
	@NotEmpty(message="Name is mandatory.....Cannot be left blank")
	@Size(min=3,max=20, message="Length of name should be between 3 to 20")
	String customerName;
	
	@Embedded
	private Address address;
	
	@Column
	@Email(message="Please enter valid email")
	private String customerEmail;
	
	@Column
	@Pattern(regexp="^[0-9]{10}$",message="Length of phone should be 10")
	String customerPhoneNumber;
	
	
}
